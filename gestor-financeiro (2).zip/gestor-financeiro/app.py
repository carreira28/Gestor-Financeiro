from flask import Flask, render_template, request, redirect, session, send_from_directory
import mysql.connector
import os

app = Flask(__name__)
app.secret_key = 'segredo_muito_forte'
app.config['UPLOAD_FOLDER'] = 'static'

def conexao_bd():
    return mysql.connector.connect(
        host="db4free.net",
        user="rcarreira",
        password="Aluno21491",
        database="db_rcarreira"
    )

def obter_dados_editar(login_id):
    conexao = conexao_bd()
    cursor = conexao.cursor(dictionary=True)
    cursor.execute("SELECT titulo, logo_nome FROM editar WHERE login_id = %s", (login_id,))
    dados = cursor.fetchone()
    conexao.close()
    return dados

@app.route("/")
def index():
    if "login_id" not in session:
        return redirect("/login")

    dados = obter_dados_editar(session["login_id"])
    return render_template("index.html", titulo=dados["titulo"], logo_nome=dados["logo_nome"])

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        nome = request.form["nome"]
        email = request.form["email"]
        conexao = conexao_bd()
        cursor = conexao.cursor(dictionary=True)
        cursor.execute("SELECT id FROM login WHERE nome = %s AND email = %s", (nome, email))
        user = cursor.fetchone()
        conexao.close()
        if user:
            session["login_id"] = user["id"]
            return redirect("/")
        else:
            return "Login inválido"
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

@app.route("/criar_conta", methods=["GET", "POST"])
def criar_conta():
    if request.method == "POST":
        nome = request.form["nome"]
        email = request.form["email"]
        conexao = conexao_bd()
        cursor = conexao.cursor()
        cursor.execute("SELECT id FROM login WHERE email = %s", (email,))
        if cursor.fetchone():
            conexao.close()
            return "Email já está em uso."

        cursor.execute("INSERT INTO login (nome, email) VALUES (%s, %s)", (nome, email))
        login_id = cursor.lastrowid
        cursor.execute("INSERT INTO editar (login_id, titulo, logo_nome) VALUES (%s, %s, %s)", (login_id, "Escolher Nome do  Gestor", "default_logo.png"))
        conexao.commit()
        conexao.close()
        return redirect("/login")
    return render_template("registo.html")

@app.route("/editar", methods=["GET", "POST"])
def editar():
    if "login_id" not in session:
        return redirect("/login")

    if request.method == "POST":
        novo_titulo = request.form["titulo"]
        logo_file = request.files["logo"]

        if logo_file and logo_file.filename:
            logo_nome = logo_file.filename
            logo_file.save(os.path.join(app.config['UPLOAD_FOLDER'], logo_nome))
        else:
            dados = obter_dados_editar(session["login_id"])
            logo_nome = dados["logo_nome"]

        conexao = conexao_bd()
        cursor = conexao.cursor()
        cursor.execute("UPDATE editar SET titulo = %s, logo_nome = %s WHERE login_id = %s", (novo_titulo, logo_nome, session["login_id"]))
        conexao.commit()
        conexao.close()

        return redirect("/")
    dados = obter_dados_editar(session["login_id"])
    return render_template("editar.html", titulo=dados["titulo"], logo_nome=dados["logo_nome"])

@app.route('/service-worker.js')
def service_worker():
    return send_from_directory('static', 'service-worker.js', mimetype='application/javascript')

if __name__ == "__main__":
    app.run(debug=True)
