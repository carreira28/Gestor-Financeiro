let deferredPrompt;
let rendimentos = 0;
let despesas = 0;

/*BD*/
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/service-worker.js')
    .then(() => console.log('Service Worker registado com sucesso.'))
    .catch((error) => console.log('Erro ao registar o Service Worker:', error));
}


// Popup de definições
const btnDefinicoes = document.getElementById('btn-definicoes');
const popup = document.getElementById('popup-definicoes');
const fecharPopup = document.getElementById('fechar-popup');

btnDefinicoes.addEventListener('click', () => {
  popup.style.display = 'block';
});

fecharPopup.addEventListener('click', () => {
  popup.style.display = 'none';
});

window.addEventListener('click', (event) => {
  if (event.target == popup) {
    popup.style.display = 'none';
  }
});


// Inicialização do gráfico
const ctx = document.getElementById('grafico-financas').getContext('2d');
const grafico = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Rendimentos', 'Despesas', 'Poupanças'],
    datasets: [{
      label: 'Valores em €',
      data: [0, 0, 0],  // Dados iniciais para o gráfico
      backgroundColor: ['#28a745', '#dc3545', '#17a2b8'],
      borderColor: ['#218838', '#c82333', '#138496'],
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
});

function adicionarRendimento() {
  const rendimentoInput = document.getElementById('rendimento');
  const valorRendimento = parseFloat(rendimentoInput.value);
  
  if (!isNaN(valorRendimento)) {
    rendimentos += valorRendimento;
    atualizarRendimentos();
    rendimentoInput.value = '';
    atualizarPoupancas();
    atualizarGrafico();  // Atualiza o gráfico com os novos dados
  }
}

function adicionarDespesa() {
  const despesaInput = document.getElementById('despesa');
  const valorDespesa = parseFloat(despesaInput.value);
  
  if (!isNaN(valorDespesa)) {
    despesas += valorDespesa;
    atualizarDespesas();
    despesaInput.value = '';
    atualizarPoupancas();
    atualizarGrafico();  // Atualiza o gráfico com os novos dados
  }
}

function atualizarRendimentos() {
  const listaRendimentos = document.getElementById('lista-rendimentos');
  const itemRendimento = document.createElement('li');
  itemRendimento.textContent = `Rendimento: ${rendimentos.toFixed(2)}€`;
  listaRendimentos.appendChild(itemRendimento);
}

function atualizarDespesas() {
  const listaDespesas = document.getElementById('lista-despesas');
  const itemDespesa = document.createElement('li');
  itemDespesa.textContent = `Despesa: ${despesas.toFixed(2)}€`;
  listaDespesas.appendChild(itemDespesa);
}

function atualizarPoupancas() {
  const poupancas = rendimentos - despesas;
  document.getElementById('poupancas-valor').textContent = `Poupanças: ${poupancas.toFixed(2)}€`;
}

function atualizarGrafico() {
  const poupancas = rendimentos - despesas;
  grafico.data.datasets[0].data = [rendimentos, despesas, poupancas];
  grafico.update();
}
document.getElementById('btn-download-pdf').addEventListener('click', () => {
  const canvas = document.getElementById('grafico-financas');
  const imagem = canvas.toDataURL('image/png', 1.0);

  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF();

  const larguraPDF = 180;
  const alturaPDF = (canvas.height * larguraPDF) / canvas.width;

  pdf.setFontSize(18);
  pdf.text("Gráfico do Resumo Financeiro Mensal", 15, 20);
  pdf.addImage(imagem, 'PNG', 15, 30, larguraPDF, alturaPDF);
  pdf.save("grafico-financas.pdf");
});

// Código para instalar o PWA
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;

  const installButton = document.getElementById('install-button');
  installButton.style.display = 'block';

  installButton.addEventListener('click', () => {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('Usuário aceitou o prompt de instalação');
      } else {
        console.log('Usuário rejeitou o prompt de instalação');
      }
      deferredPrompt = null;
    });
  });
});

window.addEventListener('load', () => {
  setTimeout(() => {
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) {
      loadingScreen.classList.add('fade-out');
      setTimeout(() => loadingScreen.remove(), 1000);
    }
  }, 1000);
});

// Registrar o Service Worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('service-worker.js')
    .then((registration) => {
      console.log('Service Worker registrado com sucesso:', registration);
    })
    .catch((error) => {
      console.error('Erro ao registrar o Service Worker:', error);
    });
}

//defenições
document.getElementById('tema').addEventListener('change', (e) => {
  document.body.className = e.target.value === 'escuro' ? 'dark-theme' : '';
});

document.getElementById('btn-limpar').addEventListener('click', () => {
  if (confirm("Tem a certeza que deseja limpar todos os dados e reiniciar?")) {
    rendimentos = 0;
    despesas = 0;

    document.getElementById('lista-rendimentos').innerHTML = '';
    document.getElementById('lista-despesas').innerHTML = '';
    document.getElementById('poupancas-valor').textContent = 'Poupanças: 0.00€';

    atualizarGrafico();
    location.reload(); 
  }
});


function atualizarDataHora() {
  const agora = new Date();
  const dia = agora.getDate().toString().padStart(2, '0');
  const mes = (agora.getMonth() + 1).toString().padStart(2, '0');
  const ano = agora.getFullYear();
  const horas = agora.getHours().toString().padStart(2, '0');
  const minutos = agora.getMinutes().toString().padStart(2, '0');
  const segundos = agora.getSeconds().toString().padStart(2, '0');
  
  document.getElementById("data-hora").textContent = `${dia}/${mes}/${ano} - ${horas}:${minutos}:${segundos}`;
}

setInterval(atualizarDataHora, 1000);
atualizarDataHora();

